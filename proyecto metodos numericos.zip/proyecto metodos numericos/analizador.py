
#matplotlib
import matplotlib.pyplot as plt
#skimage
import skimage.io as io 
from skimage import color,data
from skimage.filters import threshold_otsu
from skimage.filters import gaussian
#numpy
import numpy as np
#PIL
from PIL import Image
#os
import os


#carga la imagen que se quiere procesar


#suaviza la imagen cargada
#imagen_suavizada = gaussian(imagen, multichannel= True)


#cambia la imagen que se quiere procesar a escala de grises


def cargar_imagenes():
    vector_persona = []
    for k in range(50):
        vector_manos = []
        for i in range(5):
            imagen = io.imread("proyecto metodos numericos/dataBase/sub" +str(k +1) +"/"+str(k+1)+str(i+1)+".jpg")
            imagen_gray = color.rgb2gray(imagen)
            imagen_vec = np.ravel(imagen_gray)
            vector_manos.append(imagen_vec)
            vector_manos_aux = np.transpose(vector_manos)
        vector_persona.append(vector_manos_aux)

    mano_buscada = []
    dedos = []
    for i in range(5):
        imagen = io.imread("proyecto metodos numericos/inputImage/"+str(i+1)+".jpg")
        imagen_gray = color.rgb2gray(imagen)
        imagen_vec = np.ravel(imagen_gray)
        dedos.append(imagen_vec)
 
    mano_buscada = np.transpose(dedos)

    print(np.shape(mano_buscada))

    #descomposicion svd
    u,s,vt = np.linalg.svd(vector_persona, full_matrices=False)
    
    arreglo_aux = []

    for i in range(50):
        x, residuo, rank, sigularValues = np.linalg.lstsq(mano_buscada, u[i], -1)
        norma_residuo = np.linalg.norm(residuo)
        arreglo_aux.append(norma_residuo)

    posicion = 0
    aux_dato = arreglo_aux[0]
    for k in range(50):
        if arreglo_aux[k] < aux_dato:
            posicion = k
            aux_dato = arreglo_aux[k]


    print("la imagen corresponde al sujeto numero "+ str(posicion+1))




cargar_imagenes()


